import { IonHeader, IonTitle, IonToolbar, IonButtons, IonContent, IonMenu, IonMenuButton, IonPage, IonLabel, IonItem, IonList, IonIcon, IonFab, IonFabButton, IonCard, IonThumbnail, IonButton, IonMenuToggle, IonCardTitle, IonCardHeader, IonImg, IonDatetime, IonInput, IonCardContent, IonCardSubtitle, IonModal } from '@ionic/react';
import { barbell, barChart, book, bookmarks, calendar, chatboxEllipses, chatbubbles, chevronForwardOutline, grid, image, images, videocam, settings, people, logOut, close, notifications, happyOutline, stopwatchOutline, walkOutline, heartOutline, calculator, fastFood, happy, water } from 'ionicons/icons';
import '../components/Variables/Home.css'
import { useState } from 'react';
import { Link } from 'react-router-dom';



function Home() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedDateTime, setSelectedDateTime] = useState('');

  const handleDateTimeChange = (event) => {
    setSelectedDateTime(event.detail.value);
  };
  return (
    <>
            
      <IonMenu contentId="main-content">        
      <IonContent className="ion-padding">
        
    <IonList lines="none">

      <IonItem>
      <IonItem>
		<IonThumbnail slot="start">
        <img alt="Silhouette of mountains" src="https://ionicframework.com/docs/img/demos/thumbnail.svg" />
        </IonThumbnail>
        <IonLabel align="left">Name</IonLabel>
        </IonItem>
		<IonMenuToggle>        
      <IonFab>
      <IonFabButton size="small">   
      <IonIcon icon={close}></IonIcon>
      </IonFabButton>
      </IonFab>        
      </IonMenuToggle>    
      </IonItem>
      
      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">   
      <IonIcon icon={grid}></IonIcon>
      </IonFabButton>
      </IonFab>
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Dashboard</IonLabel>
      </IonItem>
      
      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">   
      <IonIcon icon={bookmarks}></IonIcon>
      </IonFabButton>
      </IonFab>
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Membership</IonLabel>
      </IonItem>
      
      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={videocam}></IonIcon>
      </IonFabButton>
      </IonFab>
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Videos</IonLabel>
      </IonItem>
      
      
      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={images}></IonIcon>
      </IonFabButton>
      </IonFab>
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Articles</IonLabel>
      </IonItem>
      
      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={calendar}></IonIcon>
      </IonFabButton>
      </IonFab>
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Appointment</IonLabel>
      </IonItem>

      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={image}></IonIcon>
      </IonFabButton>
      </IonFab>
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Photo Tracking</IonLabel>
      </IonItem>
      
      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={chatbubbles}></IonIcon>
      </IonFabButton>
      </IonFab>
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Chat</IonLabel>
      </IonItem>

      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={barbell}></IonIcon>
      </IonFabButton>
      </IonFab>      
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Gym Exercise</IonLabel>
      </IonItem>

      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={calendar}></IonIcon>
      </IonFabButton>
      </IonFab>      
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Gym Classes</IonLabel>
      </IonItem>

      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={barChart}></IonIcon>
      </IonFabButton>
      </IonFab>      
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">User Progress</IonLabel>
      </IonItem>

      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={chatboxEllipses}></IonIcon>
      </IonFabButton>
      </IonFab>      
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Bots</IonLabel>
      </IonItem>

      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={book}></IonIcon>
      </IonFabButton>
      </IonFab>
      
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Diary</IonLabel>
      </IonItem>

      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={settings}></IonIcon>
      </IonFabButton>
      </IonFab>      
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Settings</IonLabel>
      </IonItem>

      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={people}></IonIcon>
      </IonFabButton>
      </IonFab>
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">My Experts</IonLabel>
      </IonItem>

      <IonItem color="light">
      <IonFab>
      <IonFabButton size="small">
      <IonIcon icon={logOut}></IonIcon>
      </IonFabButton>
      </IonFab>      
      <IonIcon icon={chevronForwardOutline} slot="end" />
      <IonLabel align="center">Log Out</IonLabel>
      </IonItem>    
    </IonList>    
    
    </IonContent>
    </IonMenu>
      
    <IonPage id="main-content">
        <IonHeader>
          <IonToolbar>
            <IonButtons slot="start">
            <IonMenuButton>               
            </IonMenuButton>
            </IonButtons>
            <IonTitle align="center">Timeline</IonTitle>
            <IonIcon icon={notifications} slot="end" />
          </IonToolbar>
        </IonHeader>    
        <IonContent>

        <IonCard>
          <IonCardHeader>
            <IonCardSubtitle>Your Sleep Stats</IonCardSubtitle>
            <IonImg src='https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aGVhbHRoeSUyMGZvb2R8ZW58MHx8MHx8&w=1000&q=80'></IonImg>
            <IonCardTitle>Add Your Sleep Time</IonCardTitle>
          </IonCardHeader>
          <IonCardContent>
            <IonCard>            
            <label class="label text-muted">Your Sleep Date & Time</label>
          <IonInput class="form-control" placeholder="dd/mm/yyy" type="datetime-local" ></IonInput>                
          </IonCard>
            </IonCardContent>
            <IonCardContent>
                <IonCard>            
            <label class="label text-muted">Your Wake Up Date & Time</label>
          <IonInput class="form-control" placeholder="dd/mm/yyy" type="datetime-local" ></IonInput>
          </IonCard>
          <Link to='add-food.html'>
          <IonIcon slot="start" size='large' icon={calculator}></IonIcon>
          </Link>             
            </IonCardContent>
        </IonCard>

        <IonCard>
          <IonCardHeader>
            <IonCardSubtitle>Water Intake Reminder</IonCardSubtitle>
            <IonImg src='https://static.toiimg.com/thumb/resizemode-4,width-1200,height-900,msid-68952448/68952448.jpg'></IonImg>
            <h4 class="text-primary" align="center" color="primary">250 ml</h4>
                    <h5 align="center">Take Your Water</h5>
                    <h5 align="center">Water Help you to Control Calories.</h5>
            <IonCardTitle>Add Water Manually</IonCardTitle>
          </IonCardHeader>
          <IonCardContent>
            <IonCard>            
            <label class="label text-muted">Your Sleep Date & Time</label>
            <IonInput position="floating" class="form-control" placeholder="Time" type="time"></IonInput>
            </IonCard>  
            <IonCard>          
                        <div class="form-group">
                            <label class="label text-muted">Enter Water Amount(l)</label>
                            <IonInput position="floating" class="form-control" placeholder="Enter Amount" type="number"></IonInput>
                        </div>
                        </IonCard>
          <Link to='add-food.html'>
          <IonIcon slot="start" size='large' icon={water}></IonIcon>
          </Link>             
            </IonCardContent>
        </IonCard>

        <IonCard>
          <IonCardHeader>
            <IonCardSubtitle>Exercise time Your Currently Assigned Exercise</IonCardSubtitle>
            <IonImg src='https://health.clevelandclinic.org/wp-content/uploads/sites/3/2022/04/exerciseHowOften-944015592-770x533-1.jpg'></IonImg>
                    <h5 align="center">Jumping Rope</h5>
                    <h6 align="center">Daily Routine:Jump 10 min if no Exercise assigned</h6>
            <IonCardTitle>Add Water Manually</IonCardTitle>
          </IonCardHeader>
          <IonCardContent>
          <IonCard>            
            <label class="label text-muted">Start Time</label>
            <IonInput position="floating" class="form-control" placeholder="Time" type="time"></IonInput>
            </IonCard>
            <IonCard>            
            <label class="label text-muted">End Time</label>
            <IonInput position="floating" class="form-control" placeholder="Time" type="time"></IonInput>
            </IonCard>
          <Link to='add-food.html'>
          <IonIcon slot="start" size='large' icon={barbell}></IonIcon>
          </Link>             
            </IonCardContent>
        </IonCard>

        <IonCard>
          <IonCardHeader>
            <IonCardSubtitle>Your Today's Schedule on morning Snacks</IonCardSubtitle>
            <IonImg src="https://images.everydayhealth.com/images/healthy-snack-ideas-for-rheumatoid-arthritis-03-easy-snacks-1440x810.jpg"></IonImg>
                    <h5 align="center">Your Morning Snacks Contains</h5>
                    <h6 align="center">161 Calories</h6>
            <IonCardTitle>Add Water Manually</IonCardTitle>
          </IonCardHeader>
          <IonCardContent>
          <IonCard>            
          <div class="form-group">
                            <label class="label text-muted">Add Food</label>
                            <IonInput position="floating" class="form-control" placeholder="Enter Amount" ></IonInput>
                        </div>
            </IonCard>
            <IonCard>            
          <div class="form-group">
                            <label class="label text-muted">Suggest Food</label>
                            <IonInput position="floating" class="form-control" placeholder="Enter Amount" ></IonInput>
                        </div>
            </IonCard>
          <Link to='add-food.html'>
          <IonIcon slot="start" size='large' icon={fastFood}></IonIcon>
          </Link>             
            </IonCardContent>
        </IonCard>
      </IonContent>
    </IonPage>   
    
    
    </>
  );
}

export default Home;
