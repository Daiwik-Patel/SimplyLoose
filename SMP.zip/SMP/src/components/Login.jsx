import {useState} from "react";
import { IonButton, IonCard, IonCardContent, IonIcon, IonInput, IonItem, useIonAlert, useIonRouter, IonModal, IonHeader, IonToolbar, IonTitle, IonButtons, IonAlert, IonImg } from "@ionic/react";
import { lockClosed, logIn, person, close } from 'ionicons/icons';
import '../components/Variables/Login.css'

import { Link } from "react-router-dom";

function Login() {
    const [] = useIonAlert();
    const [email,setEmail] = useState('');
    const [password,setPassword] = useState('');
    const navigation = useIonRouter()

    console.log(email,password)

    const doLogin =() => {
            
        navigation.push('/home', 'root' , 'push')
      }
    

	const [isOpen, setIsOpen] = useState(false);
	
	return (
      <>
	  
	  
	
      <IonCard>
                <IonCardContent className="ion-padding">
                    <IonItem>
                    <IonIcon icon={person}  slot="start" > </IonIcon>
                    <IonInput position="floating" type="email" placeholder="Enter your email" value={email} onIonChange={ (e) => setEmail(e.detail.value)}></IonInput>

                    </IonItem>
                    
                    <IonItem>
                    <IonIcon icon={lockClosed} slot="start" ></IonIcon>
                    <IonInput position="floating" type="password" placeholder="Enter your password" value={password} onIonChange={(e) => setPassword(e.detail.value)}></IonInput>
                    </IonItem>

                </IonCardContent>

		<Link color="secondary" onClick={() => setIsOpen(true)}>
          Forgot Password?
        </Link>
        <IonModal isOpen={isOpen}>
          <IonHeader>
            <IonToolbar>
			  <IonTitle slot="start"> FORGET YOUR PASSWORD?</IonTitle>              
              <IonButtons slot="end">
                <IonIcon icon={close} size="large" onClick={() => setIsOpen(false)}></IonIcon>
              </IonButtons>
            </IonToolbar>
          </IonHeader>		  
		  <IonItem> 			
            <IonInput type="email" placeholder="Enter your email" ></IonInput>
          </IonItem>
		  <IonButton expand="block"> SEND EMAIL </IonButton>		  
		</IonModal>   

                <div className="ion-margin-top">
                  
                <IonButton expand="block" size="default" onClick={() => doLogin()}>
            <IonIcon icon={logIn} slot="start" size="large" />
            Login
            </IonButton>                             
            </div>
            </IonCard>      
        </>       
      );
  }
  




export default Login